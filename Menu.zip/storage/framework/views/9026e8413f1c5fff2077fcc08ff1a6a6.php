
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex justify-center items-center min-h-[calc(100vh-100px)] px-4 py-10 bg-gray-100 dark:bg-gray-900">
        <div class="w-full max-w-2xl bg-white dark:bg-gray-800 shadow-xl rounded-xl p-8 space-y-6">
            <h1 class="text-3xl font-bold text-gray-800 dark:text-white text-center">✏️ Edit Category</h1>

            <form action="<?php echo e(route('categories.update', $category)); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Category Name -->
                <div>
                    <label for="name" class="block text-lg font-medium text-gray-700 dark:text-gray-200 mb-2">
                        Category Name
                    </label>
                    <input
                        type="text"
                        name="name"
                        id="name"
                        value="<?php echo e(old('name', $category->name)); ?>"
                        required
                        class="w-full px-5 py-3 text-base rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="e.g. Drinks, Desserts"
                    >
                </div>

                <!-- Display Order -->
                <div>
                    <label for="order" class="block text-lg font-medium text-gray-700 dark:text-gray-200 mb-2">
                        Display Order <span class="text-sm text-gray-400">(optional)</span>
                    </label>
                    <input
                        type="number"
                        name="order"
                        id="order"
                        value="<?php echo e(old('order', $category->order)); ?>"
                        class="w-full px-5 py-3 text-base rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="e.g. 1, 2, 3"
                    >
                </div>

                <!-- Actions -->
                <div class="flex justify-center gap-4">
                    <button
                        type="submit"
                        class="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white text-base font-semibold rounded-md transition"
                    >
                        ✅ Update Category
                    </button>

                    <a
                        href="<?php echo e(route('categories.index')); ?>"
                        class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 hover:bg-gray-400 dark:hover:bg-gray-600 text-gray-800 dark:text-white text-base font-semibold rounded-md transition"
                    >
                        ❌ Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Users/ubejdqazimi/PhpstormProjects/Menu/menu/resources/views/categories/edit.blade.php ENDPATH**/ ?>